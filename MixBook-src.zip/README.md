# MixBook · 把你的 HTML 变成 iPhone App（IPA）

这个文件夹里已经帮你把「一个 2MB 的单文件 HTML 页面」封装成了一个完整的 iOS 原生工程：
用一个全屏 WKWebView 加载内置的 `web/index.html`，装到 iPhone 上就是一个独立 App（有图标、没有浏览器地址栏、全屏显示）。

> 说明：**HTML 不能直接改后缀变成 .ipa**。.ipa 里面必须是 arm64 的 iOS 可执行程序，只有在 macOS + Xcode（iOS SDK）里才能编译出来。所以这里给你一套「云端免费编译」的方案，**不需要你有 Mac**。

---

## 一、文件结构

```
MixBookIPA/
├── project.yml                  # XcodeGen 工程配置（用来自动生成 .xcodeproj）
├── MixBook/
│   ├── AppDelegate.swift        # App 入口
│   ├── SceneDelegate.swift      # 窗口 / 根控制器
│   ├── WebViewController.swift  # 全屏 WKWebView，加载本地 HTML
│   ├── Info.plist               # 应用配置（全屏、隐藏状态栏、允许 http 访问等）
│   ├── Assets.xcassets/         # App 图标（已生成 1024×1024）
│   └── web/index.html           # 你的网页（整个 App 的界面就是它）
└── .github/workflows/build-ipa.yml   # GitHub 云端编译脚本，产出未签名 IPA
```

想换页面内容：直接替换 `MixBook/web/index.html` 就行，文件名必须还是 `index.html`。

---

## 二、怎么拿到真正能装的 IPA（三条路，按推荐顺序）

### 路线 A：GitHub Actions 云端编译（免费、不用 Mac）✅ 推荐

1. 注册 / 登录 GitHub（免费账号即可）。
2. 新建一个仓库（Public 或 Private 都行，Private 每月也有免费额度）。
3. 把这个 `MixBookIPA` 文件夹里的**所有内容**上传到仓库根目录（注意 `.github` 文件夹要一起传，它是隐藏目录，浏览器上传时容易漏，建议用 GitHub Desktop 或网页上传时确认）。
4. 进入仓库 → 上方 **Actions** 标签 → 左侧选 `Build Unsigned IPA` → 右侧 **Run workflow** → 运行。
5. 等 5～10 分钟，点进这次运行，页面底部 **Artifacts** 里下载 `MixBook-unsigned-ipa.zip`，解压得到 **MixBook.ipa**。

这个 IPA 是「未签名」的，下一步要签自己的 Apple ID 才能装。

### 路线 B：Windows 上用 Sideloadly 签名安装（你有 Windows 电脑就能做）

1. 电脑装 **Sideloadly**（sideloadly.io，免费）。
2. iPhone 用数据线连电脑，手机上点「信任此电脑」。
3. Sideloadly 里：IPA 选刚下载的 `MixBook.ipa`，Apple ID 填你的账号（**建议用不常用的副 Apple ID，不要用主号**），点 Start。
4. 首次要在 iPhone 上：设置 → 通用 → VPN与设备管理 → 信任你的开发者证书。
5. 装好后桌面就有 MixBook 图标，点开就是全屏的 MixOS 页面。

⚠️ 免费 Apple ID 的限制：
- 签名 **7 天过期**，过期后 App 打不开，要重新用 Sideloadly 签一次（数据一般不会丢，但建议别存重要东西）
- 同时最多 3 个自签 App
- 付费开发者账号（99 美元/年）才是 1 年有效期

### 路线 C：不想折腾签名，直接当网页 App 用（最快）

如果你只是想「桌面上有个图标点开就是这个系统」：
把 `index.html` 传到任意能访问的地方（或者用 GitHub Pages 免费托管），iPhone Safari 打开 → 分享 → **添加到主屏幕**。
效果接近原生 App，只是没有独立进程、不能离线（除非页面全部内联，你这个文件基本是内联的，可以正常显示）。

---

## 三、常见问题

**Q：编译报错 `No signing certificate`？**
脚本里已经设了 `CODE_SIGNING_ALLOWED=NO`，正常不会报。如果还报，检查是否漏传了 `.github/workflows/build-ipa.yml`。

**Q：App 打开白屏 / 找不到页面？**
说明 `web/index.html` 没被打进包里。确认文件在 `MixBook/web/index.html`，且 `project.yml` 里 `MixBook/web` 是 `type: folder`（已配好）。

**Q：页面里的搜索 / 地图打不开？**
HTML 里跳转外网（bing、百度、OSM）依赖网络和 ATS 设置，`Info.plist` 里已开了 `NSAllowsArbitraryLoads`。iPhone 上如果还是失败，多半是那些站点自己在 iframe 里禁了嵌套。

**Q：想改 App 名字 / 图标？**
- 名字：`project.yml` 里 `PRODUCT_NAME` 和 `Info.plist` 的 `CFBundleDisplayName`
- 图标：替换 `Assets.xcassets/AppIcon.appiconset/icon-1024.png`（必须 1024×1024，不能带透明通道）

**Q：想让它支持横屏 / 只竖屏？**
改 `Info.plist` 的 `UISupportedInterfaceOrientations`。
